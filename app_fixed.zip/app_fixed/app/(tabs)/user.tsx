import React, { useState, useEffect } from "react";
import { StyleSheet, ScrollView, TouchableOpacity, View } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { router } from "expo-router";
import { FinancialOverview } from "@/components/ui/FinancialOverview";
import { QuickAddTripModal } from "@/components/ui/QuickAddTripModal";
import UserLevelCard from "@/components/ui/UserLevelCard";
import { calculateLevel, calculateXPForNextLevel, calculateCurrentLevelXP, getXPForTrip, addXP } from "@/utils/levelSystem";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Trip } from "@/types/trip";
import { loadTrips, saveTrips } from "@/services/tripStorage";

// FIX: KlimaTicket cost consistent with index.tsx (was 1090, now matches 1297.80)
const KLIMA_TICKET_COST = 1297.80;

export default function UserScreen() {
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userXP, setUserXP] = useState(0);
  const [userLevel, setUserLevel] = useState(1);

  useEffect(() => {
    const init = async () => {
      // FIX: load XP and trips concurrently, both properly awaited
      const [loadedTrips, storedXP] = await Promise.all([
        loadTrips(),
        AsyncStorage.getItem("userXP"),
      ]);
      setTrips(loadedTrips);
      if (storedXP) {
        const xp = parseInt(storedXP, 10);
        setUserXP(xp);
        setUserLevel(calculateLevel(xp));
      }
      setIsLoading(false);
    };
    init();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      saveTrips(trips);
    }
  }, [trips, isLoading]);

  const handleNewTrip = () => {
    setShowQuickAdd(true);
  };

  // FIX: route corrected from /(tabs)/trip/${tripId} to /trip/${tripId}
  const handleTripPress = (tripId: string) => {
    router.push(`/trip/${tripId}` as any);
  };

  const handleQuickAddSubmit = async (tripData: {
    date: Date;
    origin: string;
    destination: string;
    transportType: string;
    cost: number;
    description?: string;
    distance: number;
  }) => {
    const newTrip: Trip = {
      id: Date.now().toString(),
      date: tripData.date,
      origin: tripData.origin,
      destination: tripData.destination,
      transportType: tripData.transportType,
      cost: tripData.cost,
      distance: tripData.distance,
      description: tripData.description || "",
    };

    const tripXP = getXPForTrip(tripData.distance, tripData.transportType);
    const newXP = addXP(userXP, tripXP);

    await AsyncStorage.setItem("userXP", newXP.toString());
    setUserXP(newXP);
    setUserLevel(calculateLevel(newXP));

    // FIX: functional updater avoids stale closure (was [newTrip, ...trips])
    setTrips((prev) => [newTrip, ...prev]);
    setShowQuickAdd(false);
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) return "Today";
    if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
  };

  const totalCost = trips.reduce((sum, trip) => sum + trip.cost, 0);

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ThemedText>Loading trips...</ThemedText>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <ThemedText type="title">My Climate Journey</ThemedText>
        <ThemedText style={styles.subtitle}>Track your impact and savings</ThemedText>
      </View>

      <UserLevelCard
        level={userLevel}
        currentXP={calculateCurrentLevelXP(userXP, userLevel)}
        xpToNextLevel={calculateXPForNextLevel(userLevel)}
      />

      <FinancialOverview
        totalTrips={trips.length}
        totalDistance={trips.reduce((sum, trip) => sum + trip.distance, 0)}
        totalCost={totalCost}
        klimaTicketCost={KLIMA_TICKET_COST}
      />

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <ThemedText type="subtitle">Recent Trips</ThemedText>
          <TouchableOpacity style={styles.addButton} onPress={handleNewTrip}>
            <IconSymbol name="plus.circle.fill" size={24} color="#007AFF" />
            <ThemedText style={styles.addButtonText}>Add Trip</ThemedText>
          </TouchableOpacity>
        </View>

        {trips.map((trip) => (
          <TouchableOpacity key={trip.id} onPress={() => handleTripPress(trip.id)}>
            <ThemedView style={styles.tripCard}>
              <View style={styles.tripHeader}>
                <View>
                  <ThemedText style={styles.tripTitle}>
                    {trip.origin} → {trip.destination}
                  </ThemedText>
                  <ThemedText style={styles.tripDate}>
                    {formatDate(trip.date)} {formatTime(trip.date)}
                  </ThemedText>
                </View>
                <ThemedText style={styles.tripCost}>€{trip.cost.toFixed(2)}</ThemedText>
              </View>
              <View style={styles.tripDetails}>
                <View style={styles.tripDetail}>
                  <IconSymbol name="bus" size={16} color="#666" />
                  <ThemedText style={styles.tripDetailText}>{trip.transportType}</ThemedText>
                </View>
                {trip.description && (
                  <View style={styles.tripDetail}>
                    <IconSymbol name="text.bubble" size={16} color="#666" />
                    <ThemedText style={styles.tripDetailText}>{trip.description}</ThemedText>
                  </View>
                )}
              </View>
            </ThemedView>
          </TouchableOpacity>
        ))}
      </View>

      <QuickAddTripModal
        visible={showQuickAdd}
        onClose={() => setShowQuickAdd(false)}
        onSubmit={handleQuickAddSubmit}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  header: { marginBottom: 20 },
  subtitle: { fontSize: 16, color: "#666", marginTop: 4 },
  section: { marginTop: 20 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  addButton: { flexDirection: "row", alignItems: "center", gap: 4, padding: 8, backgroundColor: "#f0f0f0", borderRadius: 20 },
  addButtonText: { fontSize: 14, color: "#007AFF", fontWeight: "500" },
  tripCard: { padding: 16, borderRadius: 12, marginBottom: 12, backgroundColor: "#fff", shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  tripHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 },
  tripTitle: { fontSize: 16, fontWeight: "600", marginBottom: 4 },
  tripDate: { fontSize: 14, color: "#666" },
  tripCost: { fontSize: 18, fontWeight: "600", color: "#007AFF" },
  tripDetails: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  tripDetail: { flexDirection: "row", alignItems: "center", gap: 4 },
  tripDetailText: { fontSize: 14, color: "#666" },
});
