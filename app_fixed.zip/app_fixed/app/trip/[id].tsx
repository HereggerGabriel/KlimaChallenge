import { useEffect, useState } from "react";
import { StyleSheet, ScrollView, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { IconSymbol } from "@/components/ui/IconSymbol";
import { Trip } from "@/types/trip";
import { getTripById } from "@/services/tripStorage";

export default function TripDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [trip, setTrip] = useState<Trip | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // FIX: load the real trip from AsyncStorage using the shared storage service
  useEffect(() => {
    const fetch = async () => {
      if (!id) return;
      const found = await getTripById(id);
      setTrip(found);
      setIsLoading(false);
    };
    fetch();
  }, [id]);

  if (isLoading) {
    return (
      <ThemedView style={styles.container}>
        <ThemedText>Loading...</ThemedText>
      </ThemedView>
    );
  }

  if (!trip) {
    return (
      <ThemedView style={styles.container}>
        <ThemedText>Trip not found</ThemedText>
      </ThemedView>
    );
  }

  const formatDate = (date: Date) =>
    new Date(date).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });

  const formatTime = (date: Date) =>
    new Date(date).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });

  return (
    <ScrollView style={styles.container}>
      <ThemedView style={styles.header}>
        <ThemedText type="title" style={styles.destination}>
          {trip.origin} → {trip.destination}
        </ThemedText>
        <ThemedText style={styles.date}>
          {formatDate(trip.date)} at {formatTime(trip.date)}
        </ThemedText>
      </ThemedView>

      <ThemedView style={styles.section}>
        <ThemedText type="subtitle" style={styles.sectionTitle}>
          Trip Overview
        </ThemedText>
        <ThemedView style={styles.overviewCard}>
          <ThemedView style={styles.overviewItem}>
            <IconSymbol name="bus" size={24} color="#007AFF" />
            <ThemedText style={styles.overviewLabel}>Transport</ThemedText>
            <ThemedText style={styles.overviewValue}>{trip.transportType}</ThemedText>
          </ThemedView>
          <ThemedView style={styles.overviewItem}>
            <IconSymbol name="paperplane.fill" size={24} color="#007AFF" />
            <ThemedText style={styles.overviewLabel}>Distance</ThemedText>
            <ThemedText style={styles.overviewValue}>{trip.distance} km</ThemedText>
          </ThemedView>
          <ThemedView style={styles.overviewItem}>
            <IconSymbol name="eurosign.circle" size={24} color="#007AFF" />
            <ThemedText style={styles.overviewLabel}>Cost</ThemedText>
            <ThemedText style={styles.overviewValue}>€{trip.cost.toFixed(2)}</ThemedText>
          </ThemedView>
        </ThemedView>
      </ThemedView>

      {trip.description ? (
        <ThemedView style={styles.section}>
          <ThemedText type="subtitle" style={styles.sectionTitle}>
            Notes
          </ThemedText>
          <ThemedText style={styles.description}>{trip.description}</ThemedText>
        </ThemedView>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    padding: 20,
    paddingTop: 40,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  destination: { fontSize: 24, marginBottom: 8 },
  date: { fontSize: 14, opacity: 0.7 },
  section: { padding: 20 },
  sectionTitle: { fontSize: 20, marginBottom: 16 },
  overviewCard: {
    flexDirection: "row",
    justifyContent: "space-around",
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  overviewItem: { alignItems: "center" },
  overviewLabel: { fontSize: 14, opacity: 0.7, marginTop: 8 },
  overviewValue: { fontSize: 16, fontWeight: "600", marginTop: 4 },
  description: { fontSize: 16, lineHeight: 24, opacity: 0.8 },
});
